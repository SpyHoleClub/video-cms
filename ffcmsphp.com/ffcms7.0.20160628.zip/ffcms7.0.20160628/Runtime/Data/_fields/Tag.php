<?php
return array (
  0 => 'tag_id',
  1 => 'tag_sid',
  2 => 'tag_name',
  '_autoinc' => false,
  '_type' => 
  array (
    'tag_id' => 'mediumint(8)',
    'tag_sid' => 'tinyint(1)',
    'tag_name' => 'varchar(50)',
  ),
);
?>