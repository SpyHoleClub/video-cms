<?php
return array (
  0 => 'm_cid',
  1 => 'm_list_id',
  2 => 'm_name',
  3 => 'm_order',
  '_autoinc' => true,
  '_pk' => 'm_cid',
  '_type' => 
  array (
    'm_cid' => 'int(10) unsigned',
    'm_list_id' => 'int(10) unsigned',
    'm_name' => 'varchar(30)',
    'm_order' => 'int(11)',
  ),
);
?>