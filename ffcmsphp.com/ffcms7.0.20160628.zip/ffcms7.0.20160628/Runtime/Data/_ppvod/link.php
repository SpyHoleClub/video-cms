<?php
return array (
  0 => 
  array (
    'link_id' => '2',
    'link_name' => '飞飞影视系统',
    'link_logo' => '',
    'link_url' => 'http://www.ffcms.cn',
    'link_order' => '1',
    'link_type' => '1',
  ),
);
?>