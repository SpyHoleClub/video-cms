<?php
return array (
  0 => 
  array (
    'slide_id' => '17',
    'slide_oid' => '2',
    'slide_cid' => '1',
    'slide_name' => 'hj',
    'slide_logo' => '',
    'slide_pic' => '/Uploads/slide/2015-03-04/54f6a258a7893.jpg',
    'slide_url' => 'ghn',
    'slide_content' => '',
    'slide_status' => '1',
  ),
);
?>