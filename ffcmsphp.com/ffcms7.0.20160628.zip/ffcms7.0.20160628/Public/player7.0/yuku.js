﻿function $Showhtml(){
	player = '<embed type="application/x-shockwave-flash" src="http://static.youku.com/v1.0.0413/v/swf/loader.swf" id="movie_player" name="movie_player" bgcolor="#FFFFFF" quality="high" allowfullscreen="true" flashvars="VideoIDS='+Player.Url+'&embedid=MTEzLjE0My4xNTkuOTYCMTUwNjk2NTE3AmkueW91a3UuY29tAi91L1VOakl6T1RjMk1UVXk%3D&isAutoPlay=true&isDebug=false&UserID=&playMovie=true&MMControl=false&MMout=false" pluginspage="http://www.macromedia.com/go/getflashplayer" width="100%" height="'+Player.Height+'">';	
	return player;
}
Player.Show();
if(Player.Second){
	$$('buffer').style.height = Player.Height-39;
	$$("buffer").style.display = "block";
	setTimeout("Player.BufferHide();",Player.Second*1000);
}