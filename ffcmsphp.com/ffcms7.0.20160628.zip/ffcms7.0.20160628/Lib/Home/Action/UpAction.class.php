<?php
namespace Home\Action;
use Common\Action\HomeAction;
class UpAction extends HomeAction{
 				
}
?>