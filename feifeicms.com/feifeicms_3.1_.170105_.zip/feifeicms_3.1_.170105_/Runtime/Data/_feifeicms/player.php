<?php
return array (
  'xfplay' => 
  array (
    0 => '影音先锋',
    1 => '需下载安装影音先锋',
    2 => '0',
  ),
  'xigua' => 
  array (
    0 => '西瓜影音',
    1 => '需下载安装西瓜播放器',
    2 => '0',
  ),
  'jjvod' => 
  array (
    0 => '吉吉影音',
    1 => '需下载安装吉吉影音播放器',
    2 => '0',
  ),
  'ffhd' => 
  array (
    0 => '非凡影音',
    1 => '需下载安装非凡影音播放器',
    2 => '0',
  ),
  'iframe' => 
  array (
    0 => '框架引用',
    1 => 'iframe引用任何网页',
    2 => '0',
  ),
  'youku' => 
  array (
    0 => '优酷网',
    1 => 'youku',
    2 => '0',
  ),
  'ykyun' => 
  array (
    0 => '优酷云',
    1 => 'youkuyun',
    2 => '0',
  ),
  'tudou' => 
  array (
    0 => '土豆网',
    1 => 'tudou',
    2 => '0',
  ),
  'sohu' => 
  array (
    0 => '搜狐',
    1 => 'sohu',
    2 => '0',
  ),
  'iqiyi' => 
  array (
    0 => '爱奇艺',
    1 => 'iqiyi',
    2 => '0',
  ),
  'qq' => 
  array (
    0 => '腾讯视频',
    1 => 'qq',
    2 => '0',
  ),
  'down' => 
  array (
    0 => '下载',
    1 => 'down',
    2 => '0',
  ),
  'pptv' => 
  array (
    0 => 'PPTV',
    1 => 'pptv',
    2 => '0',
  ),
  'mgtv' => 
  array (
    0 => '芒果TV',
    1 => 'mgtv',
    2 => '0',
  ),
  'wasu' => 
  array (
    0 => '华数TV',
    1 => 'wasu',
    2 => '0',
  ),
  'kankan' => 
  array (
    0 => '响巢看看',
    1 => 'kankan',
    2 => '0',
  ),
  'ckplayer' => 
  array (
    0 => 'CKPLAYER',
    1 => 'ckplayer',
    2 => '0',
  ),
  'letv' => 
  array (
    0 => '乐视网',
    1 => 'letv',
    2 => '3',
  ),
  'acfun' => 
  array (
    0 => 'acfun',
    1 => 'acfun',
    2 => '0',
  ),
  'bilibili' => 
  array (
    0 => 'bilibili',
    1 => 'bilibili',
    2 => '0',
  ),
  'tv189' => 
  array (
    0 => 'tv189',
    1 => 'tv189',
    2 => '0',
  ),
  'baofeng' => 
  array (
    0 => 'baofeng',
    1 => 'baofeng',
    2 => '0',
  ),
  'xunlei' => 
  array (
    0 => 'xunlei',
    1 => 'xunlei',
    2 => '0',
  ),
  'm1905' => 
  array (
    0 => 'M1905',
    1 => 'm1905',
    2 => '0',
  ),
  'cntv' => 
  array (
    0 => 'CNTV',
    1 => 'cntv',
    2 => '0',
  ),
  'fun' => 
  array (
    0 => '风行',
    1 => 'fun',
    2 => '0',
  ),
);
?>