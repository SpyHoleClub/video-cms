<?php
/* @name Api资源共享插件 
 * @支持IP授权，支持缓存
 * http://www.xxxx.com/index.php?s=plus-api-json-vodids-12,13,14-cid-8-limit-20-wd-刘德华-h-24-p-22-play-qvod-inputer-admin
 * 2016.11.28 
 * qq:271513820
 */
class ApiAction extends HomeAction{
	
	//判断IP是否合法
	public function _initialize(){
		if(C('collect_ips')){
			if( !in_array(get_client_ip(), explode(',', C('collect_ips'))) ){
				exit( json_encode( array('status'=>501, 'data'=>'IP未授权') ) );
			}
		}
  }

	//json接口
	public function json(){
		//默认定义
		$params = array();
		$params['field'] = 'vod_id,vod_cid,vod_name,vod_title,vod_type,vod_keywords,vod_actor,vod_director,vod_content,vod_pic,vod_hits,vod_stars,vod_area,vod_language,vod_year,vod_continu,vod_total,vod_addtime,vod_server,vod_play,vod_url,vod_inputer,vod_filmtime,vod_reurl,vod_length,vod_weekday,vod_copyright,vod_state,vod_tv,list_name';
		$params['order'] = 'vod_addtime asc,vod_id asc';
		//获取地址栏参数
		$params['limit'] = !empty($_GET['limit'])?intval($_GET['limit']):20;
		$params['vodids'] = htmlspecialchars($_GET['vodids']);
		$params['cid'] = intval($_GET['cid']);
		$params['play'] = htmlspecialchars($_GET['play']);
		$params['inputer'] = htmlspecialchars($_GET['inputer']);
		$params['h'] = intval($_GET['h']);
		$params['wd'] = htmlspecialchars($_GET['wd']);
		//查询条件
		$where = array();
		$where['vod_status'] = 1;
		//影片ids
		if($params['vodids']){
			$where['vod_id'] = array('in',$params['vodids']);
		}
		//影片分类
		if($params['cid']){
			//$where['vod_cid'] = dc_list_sql_in($url['cid']);
			$where['vod_cid'] = array('eq', $params['cid']);
		}else{
			$where['vod_cid'] = array('gt',0);
		}
		//影片编辑(资源站入库标识)
		if($params['inputer']){
			$where['vod_inputer'] = array('eq',$params['inputer']);
		}	
		//播放器组
		if($params['play']){
			$where['vod_play'] = array('like','%'.$params['play'].'%');
		}
		//影片时间
		if($params['h']){
			if($params['h'] >= 24){
				$day = ceil($url['h']/24);
				$where['vod_addtime'] = array('gt',ff_linux_time($day));
			}
			$params['order'] = 'vod_addtime desc,vod_id desc';
		}
		//影片搜索
		if($params['wd']){
			$wd = urldecode($params['wd']);
			$search = array();
			$search['vod_name'] = array('like','%'.$wd.'%');
			$search['vod_actor'] = array('like','%'.$wd.'%');
			$search['vod_director'] = array('like','%'.$wd.'%');
			$search['_logic'] = 'or';
			$where['_complex'] = $search;
		}
		// 分页参数
		$params['page_is']= true;
		$params['page_id']= 'ffapi';
		$params['page_p']= !empty($_GET['p'])?intval($_GET['p']):1;
		// 缓存参数
		$params['cache_name'] = md5(C('cache_foreach_prefix').'_'.implode('_',$params));
		$params['cache_time']= 600;
		// 拼装data 根据查询条件查询数据库 
		$array_data = D('VodView')->ff_select_page($params, $where);
		foreach($array_data as $key=>$val){
			$array_data[$key]['vod_pic'] = ff_url_img($array_data[$key]['vod_pic'], $array_data[$key]['vod_content']);
			$array_data[$key]['vod_addtime'] = date('Y-m-d H:i:s',$array_data[$key]['vod_addtime']);
			if($params['play']){
				$array_data[$key]['vod_url'] = $this->json_url($val['vod_play'], $val['vod_url'], $url['play']);
				$array_data[$key]['vod_play'] = trim($params['play']);
			}
		}
		// 拼装page
		$page = $_GET['ff_page_ffapi'];
		$array_page = array('pageindex'=>$page['currentpage'], 'pagecount'=>$page['totalpages'], 'pagesize'=>$params['limit'], 'recordcount'=>$page['records']);
		// 拼装list
		$params = array();
		$params['field'] = 'list_id,list_name';
		$params['limit'] = false;
		$params['order'] = 'list_id asc,list_oid';
		$params['cache_name'] = C('cache_foreach_prefix').'_ffapi_list';
		$params['cache_time']= 3600;
		$array_list = D("List")->ff_select_page($params,'list_sid=1 and list_status=1');
		echo json_encode(array('status'=>200,'page'=>$array_page, 'list'=>$array_list, 'data'=>$array_data));
  }
	
	public function json_url($vod_play, $vod_url, $url_play){
		$array_play = explode('$$$',$vod_play);
		$key = array_search(trim($url_play),$array_play);
		$array_url = explode('$$$',$vod_url);
		return $array_url[$key];
	}							
}
?>