<?php
class MyAction extends HomeAction{
  public function show(){
		$id = !empty($_GET['tpl'])?$_GET['tpl']:'new';
		$skin = 'my_'.trim($id);
		if($_GET['ajax']){
			$skin .= '_ajax';
		}
		$this->display($skin);
	}
}
?>