<?php
class CjAction extends BaseAction{
	// 展示列表
	public function show(){
		$list = D('Cj')->order('cj_id asc')->select();
		$this->assign('list_cj',$list);
		$this->assign('jumpurl',F('_cj/xucai'));
		$this->display('./Public/system/cj_list.html');
	}
	// 添加编辑采集节点
  public function add(){
		$id = intval($_GET['id']);
	  $rs = D("Cj");
		if ($id) {
      $where['cj_id'] = $id;
			$list = $rs->where($where)->find();
		}
		$this->assign($list);
		$this->display('./Public/system/cj_add.html');
  }
	// 添加采集节点
	public function insert() {
		$rs = D("Cj");
		if ($rs->create()) {
			if ( false !==  $rs->add() ) {
				redirect('?s=Admin-Cj-Show');
			}else{
				$this->error($rs->getError().'添加资源库地址失败！');
			}
		}else{
		    $this->error($rs->getError());
		}	
	}
	// 更新友情链接
	public function update(){
		$rs = D("Cj");
		if ($rs->create()) {
			$list = $rs->save();
			if ($list !== false) {
			    redirect('?s=Admin-Cj-Show');
			}else{
				$this->error("更新资源库地址失败！");
			}
		}else{
			$this->error($rs->getError());
		}
	}	
	// 删除资源库
	public function del(){
		$where['cj_id'] = $_GET['id'];
		D("Cj")->where($where)->delete();
		redirect('?s=Admin-Cj-Show');
	}
	// 资源站处理
	public function api(){
		//申明变量
		$array_url = array(); //本地程序跳转参数
		//获取跳转参数
		$array_url['action'] = $_GET['action']; //是否入库(all/day/ids/show)
		$array_url['cjid'] = intval($_GET['cjid']); //合作渠道ID
		$array_url['xmlurl'] = base64_decode($_GET['xmlurl']); //资源库网址
		$array_url['pic'] = $_GET['pic']; //是否重采资料
		//
		$array_url['vodids'] = $_GET['vodids']; if($_POST['ids']){$array_url['vodids'] = implode(',',$_POST['ids']);}//指定视频ID	
		$array_url['cid'] = $_GET['cid']; //指定视频分类
		$array_url['wd'] = $_GET['wd']; if($_POST['wd']){$array_url['wd'] = trim($_POST['wd']);} //指定关键字
		$array_url['h'] = intval($_GET['h']); //指定时间
		$array_url['p'] = !empty($_GET['p'])?intval($_GET['p']):1;$array_url['page'] = $array_url['p']; //指定分页		
		//
		$array_url['inputer'] = $_GET['inputer']; //指定资源库频道
		$array_url['play'] = $_GET['play']; //指定播放器组(如不指定则为目标站的全部播放器组)
		// 调用抓取数据处理函数
		$json_data = $this->get_api_data($array_url);
		// 是否采集入库
		if( in_array($array_url['action'], array('ids','day','all','week')) ){
			echo'<style type="text/css">li{font-size:12px;color:#333;line-height:21px}span{font-weight:bold;color:#FF0000}</style><div id="show"><li>共有<span>'.$json_data['page']['recordcount'].'</span>个数据，需要采集<span>'.$json_data['page']['pagecount'].'</span>次，正在执行第<span color=green>'.$array_url['page'].'</span>次采集任务，每一次采集<span>'.$json_data['page']['pagesize'].'</span>个。</li>';
			// 将采集的数据添加到本地数据库
			$rs = D('VodXml');
			foreach($json_data['listvod'] as $key=>$vod){
				$array_vod_play = explode('$$$',$vod['vod_play']);
				$array_vod_url = explode('$$$',$vod['vod_url']);
				echo '<li>第<span>'.(($array_url['page']-1)*$json_data['page']['pagesize']+$key+1).'</span>个影片有<span>'.count($array_vod_play).'</span>组播放地址 ['.ff_list_find($vod['vod_cid']).'] '.$vod['vod_name'].' <font color="green">';
				//有几组播放地址就添加几次
				foreach($array_vod_play as $ii=>$value){
					$vod['vod_inputer'] = 'xml_'.$array_url['cjid'];
					$vod['vod_play'] = $value;
					$vod['vod_url'] = trim($array_vod_url[$ii]);
					echo $rs->xml_insert($vod, $array_url['pic']);
				}
				echo '</font></li>';
				ob_flush();flush();
			}
			echo '</div>';
			//是否记录断点续采
			if( in_array($array_url['action'],array('day','week','all')) ){
				if($array_url['page'] < $json_data['page']['pagecount']){
					//缓存断点续采
					$jumpurl = str_replace('FFLINK',($array_url['page']+1),$json_data['tpl']['pageurl']);
					F('_cj/xucai',$jumpurl);
					//跳转到下一页
					echo C('collect_time').'秒后将自动采集下一页!';
					echo '<meta http-equiv="refresh" content='.C('collect_time').';url='.$jumpurl.'>';
				}else{
					//清除断点续采
					F('_cj/xucai',NULL);
					echo '<div>恭喜您，所有采集任务已经完成，返回[<a href="?s=Admin-Vod-Show">视频管理中心</a>]，查看[<a href="?s=Admin-Vod-Show-vod_cid-0">需要人工再次审核的数据</a>]!</div>';					
				}
			}
		}else{
			//列表分页的方式展示抓取的数据
			$array_url['vodids'] = '';
			$this->assign($array_url);
			$this->assign($json_data['tpl']);
			$this->assign('list_class',$json_data['listclass']);
			$this->assign('list_vod',$json_data['listvod']);
			$this->display('./Public/system/cj_show.html');
		}
	}
	// 抓取数据(统一接口)
	public function get_api_data($array_url){
		//组合资源库URL地址并获取XML资源
		$http_url = $array_url['xmlurl'].'index.php?s=plus-api-json-action-'.$array_url['action'].'-vodids-'.$array_url['vodids'].'-cid-'.$array_url['cid'].'-play-'.$array_url['play'].'-inputer-'.$array_url['inputer'].'-wd-'.urlencode($array_url['wd']).'-h-'.$array_url['h'].'-p-'.$array_url['page'];
		$json = ff_file_get_contents($http_url);
		// 资源库状态判断
		if ($json) {
			$json = json_decode($json);
			if($json->status == 501){
				$this->error("连接API资源库成功，但服务器IP未获得授权。");
			}
			if(!$json->list){
				$this->error("连接APi资源库成功、但数据格式不正确。");
			}
		}else{
			$this->error("连接API资源库失败、通常为服务器网络不稳定或禁用了采集。");
		}
		// 获取到的远程分页数据
		$array_page = array();
		$array_page['pageindex'] = $json->page->pageindex;
		$array_page['pagecount'] = $json->page->pagecount;
		$array_page['pagesize'] = $json->page->pagesize;
		$array_page['recordcount'] = $json->page->recordcount;
		// 获取到的远程栏目数据
		$array_list = array();
		foreach($json->list as $key=>$value){
			$array_list[$key]['list_id'] = $value->list_id;
			$array_list[$key]['list_name'] = $value->list_name;
			$array_list[$key]['bind_id'] = $array_url['cjid'].'_'.$array_list[$key]['list_id'];
		}			
		// 生成本地模板参数
		$array_tpl = array();
		$array_url['p'] = 'FFLINK';
		$array_url['xmlurl']=base64_encode($array_url['xmlurl']);//需要转码
		$array_tpl['pageurl'] = U('Admin-Cj/api',$array_url);
		$array_tpl['pagelist'] = '共'.$array_page['recordcount'].'条数据&nbsp;页次:'.$array_page['pageindex'].'/'.$array_page['pagecount'].'页&nbsp;'.getpage($array_page['pageindex'],$array_page['pagecount'],5,$array_tpl['pageurl'],'pagego(\''.$array_tpl['pageurl'].'\','.$array_page['pagecount'].')');	
		// 组合入库数据
		$array_vod = array();
		foreach($json->data as $key=>$value){
			$array_vod[$key]['vod_id'] = $value->vod_id;
			$array_vod[$key]['vod_cid'] = intval(ff_bind_id($array_url['cjid'].'_'.$value->vod_cid));
			$array_vod[$key]['list_name'] = $value->list_name;
			$array_vod[$key]['vod_name'] = $value->vod_name;
			$array_vod[$key]['vod_title'] = $value->vod_title;
			$array_vod[$key]['vod_keywords'] = $value->vod_keywords;
			$array_vod[$key]['vod_type'] = $value->vod_type;
			$array_vod[$key]['vod_actor'] = $value->vod_actor;
			$array_vod[$key]['vod_director'] = $value->vod_director;
			$array_vod[$key]['vod_content'] = $value->vod_content;
			$array_vod[$key]['vod_pic'] = $value->vod_pic;
			$array_vod[$key]['vod_pic_bg'] = $value->vod_pic_bg;
			$array_vod[$key]['vod_pic_slide'] = $value->vod_pic_slide;
			$array_vod[$key]['vod_area'] = $value->vod_area;
			$array_vod[$key]['vod_language'] = $value->vod_language;
			$array_vod[$key]['vod_year'] = $value->vod_year;
			$array_vod[$key]['vod_total'] = intval($value->vod_total);
			$array_vod[$key]['vod_continu'] = !empty($value->vod_continu) ? $value->vod_continu : 0;
			$array_vod[$key]['vod_isend'] = !empty($value->vod_isend) ? $value->vod_isend : 1;
			$array_vod[$key]['vod_stars'] = !empty($value->vod_stars) ? $value->vod_stars : 1;
			$array_vod[$key]['vod_hits'] = !empty($value->vod_hits) ? $value->vod_hits : 0;
			$array_vod[$key]['vod_status'] = !empty($value->vod_status) ? $value->vod_status : 1;
			$array_vod[$key]['vod_play'] = $value->vod_play;
			$array_vod[$key]['vod_url'] = $value->vod_url;
			$array_vod[$key]['vod_server'] = $value->vod_server;	
			$array_vod[$key]['vod_inputer'] = 'xml_'.$array_url['cjid'];
			$array_vod[$key]['vod_reurl'] = str_replace('||','//',$value->vod_reurl);
			if(!$array_vod[$key]['vod_reurl']){
				$array_vod[$key]['vod_reurl'] = $array_url['xmlurl'].$array_vod[$key]['vod_id'];
			}
			$array_vod[$key]['vod_filmtime'] = !empty($value->vod_filmtime) ? $value->vod_filmtime : time();
			$array_vod[$key]['vod_length'] = $value->vod_length;
			$array_vod[$key]['vod_addtime'] = $value->vod_addtime;
			//$array_vod[$key]['vod_weekday'] = $value->vod_weekday;
			//$array_vod[$key]['vod_series'] = $value->vod_series;
			//$array_vod[$key]['vod_copyright'] = $value->vod_copyright;
			$array_vod[$key]['vod_state'] = !empty($value->vod_state) ? $value->vod_state : '正片';
			$array_vod[$key]['vod_version'] = $value->vod_version;
			$array_vod[$key]['vod_tv'] = $value->vod_tv;
		}
		//dump($array_vod);
		//$array['url'] = $array_url; //远程URL变量
		$array['tpl'] =	$array_tpl; //本地模板变量
		$array['page'] = $array_page; //远程分页数据
		$array['listclass'] = $array_list; //远程栏目数据
		$array['listvod'] = $array_vod; //远程内容数据
		return $array;
	}	
	// 检测第三方资源分类是否绑定
	public function setbind(){
		$rs = M("List");
		$list = $rs->field('list_id,list_pid,list_sid,list_name')->where('list_sid = 1')->order('list_id asc')->select();
		foreach($list as $key=>$value){
			if(!ff_list_isson($list[$key]['list_id'])){
				unset($list[$key]);
			}
		}
		$array_bind = F('_cj/bind');
		$this->assign('vod_cid',$array_bind[$_GET['bind']]);//绑定后的系统分类
		$this->assign('vod_list',$list);
		$this->display('./Public/system/cj_setbind.html');
	}
	// 存储第三方资源分类绑定
  public function insertbind(){
		$bindcache = F('_cj/bind');
		if (!is_array($bindcache)) {
			$bindcache = array();
			$bindcache['1_1'] = 0;
		}
		$bindkey = trim($_GET['bind']);
		$bindinsert[$bindkey] = intval($_GET['cid']);
		$bindarray = array_merge($bindcache,$bindinsert);
		F('_cj/bind',$bindarray);
		exit('ok');
	}	
	// 资源站定时采集
	public function win(){
		$list = D('Cj')->order('cj_id asc')->select();
		$this->assign('list_cj',$list);
		$this->display('./Public/system/cj_time_win.html');
	}
	// 执行定时采集任务
	public function wait(){
		$infos = D("List")->field('list_id')->where('list_sid=1')->order('list_id asc')->select();
		foreach($infos as $key=>$value){
			$list[$key] = $value['list_id'];
		}
		$this->assign('list_vod_all',implode(',',$list));
		//
		$array = $_REQUEST['ds'];
		$array['min'] = $array['caiji']+$array['data'];
		$this->assign($array);
		$this->display('./Public/system/cj_time_wait.html');
	}
}
?>