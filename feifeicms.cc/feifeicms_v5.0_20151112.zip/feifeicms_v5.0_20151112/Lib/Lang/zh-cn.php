<?php
return array(
	'appname'=>'飞飞CMS',
	'ppvod_welcome'=>'欢迎使用飞飞CMS 5.0.20151112版',
	'ppvod_version'=>'5.0.20151112',
	'ppvod_homeurl'=>'http://www.feifeicms.cc',
	'ppvod_version_js'=>'http://api.muyu.cc/version2.js',	
	'ppvod_tj'=>'PGRpdiBzdHlsZT0iZGlzcGxheTpub25lIj48c2NyaXB0IHNyYz0iaHR0cDovL3MyMy5jbnp6LmNvbS9zdGF0LnBocD9pZD01ODEyNTE5JndlYl9pZD01ODEyNTE5IiBsYW5ndWFnZT0iSmF2YVNjcmlwdCI+PC9zY3JpcHQ+PC9kaXY+',
	'install_error'=>'已经安装过飞飞影视导航系统,重新安装请先删除Conf/install.lock 文件!',
	'install_success'=>'恭喜您！飞飞影视导航系统安装完成，1秒后自动进入后台管理!',	
	'install_db_connect'=>'数据库连接失败!请检查数据库连接参数!',
	'install_db_select'=>'数据库建立失败,请手动创建或者填写系统管理员分配的数据库名!',	
	'login_username_check'=>'管理员帐号必须填写！',	
	'login_password_check'=>'管理员密码必须填写！',
	'login_username_not'=>'用户不存在，请重新输入！',
	'login_password_not'=>'用户密码错误，请重新输入！',
	'login_out'=>'已经安全关闭管理后台！',			
);
?>