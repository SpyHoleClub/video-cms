var hash = {'32' : '\u3000'}; 
// ���תȫ�� 
function sbc2dbc(str) { 
    var ret = [], i = 0, len = str.length, code, chr; 
    for (; i < len; ++i) { 
        code = str.charCodeAt(i); 
        chr = hash[code]; 
        if (!chr && code > 31 && code < 127) { 
            chr = hash[code] = String.fromCharCode(code + 65248); 
        } 
        ret[i] = chr ? chr : str.charAt(i); 
    } 
    return ret.join(''); 
} 
var hostname;
var hostname2;
var hostnametxt;
var lf=window.location.host.toLowerCase().split(".");
hostname2=sbc2dbc(window.location.host.toUpperCase());
if (lf.length>1){
	hostname=lf[lf.length-2] + "." + lf[lf.length-1]
	hostnametxt="www." + hostname.substring(0,3) + hostname.substring(3,hostname.length);
	document.title=document.title+hostname2;
	if (document.getElementById("WebUrl")){
		document.getElementById("WebUrl").innerHTML=hostname2;
	}
	if (document.getElementById("logo")){
		document.getElementById("logo").innerHTML=hostnametxt;
	}
}
window.status=hostname2;

function StayPosition(speed){
	this.objs = [];
	this.speed = speed || 0.1;
	this.timer = this.round = this.obj = this.end = null;
	if(StayPosition.initialize !== true){
		function correct(func, obj){
			return function(){
				func.call(obj);
			}
		}
		StayPosition.prototype.start = function(){
			this.timer = setInterval(correct(this.run, this), 33);
		}
		StayPosition.prototype.stop = function(){
			clearInterval(this.timer);
		}
		StayPosition.prototype.capitalize = function(prop){return prop.replace(/^[a-z]/, function(a){return a.toUpperCase();})}
		StayPosition.prototype.add = function(dom, prop){
			var offset = prop ? "offset" + this.capitalize(prop) : "offsetTop";
			var scroll = prop ? "scroll" + this.capitalize(prop) : "scrollTop";
			prop = prop ? prop : this.offset.slice(6).toLowerCase();
			this.objs.push({"dom": dom, "prop": {"size": dom[offset], "name": prop, "offset": offset, "scroll": scroll}});
		}
		StayPosition.prototype.run = function(){
			for(var i = 0, l = this.objs.length; i < l; i++){
				this.obj = this.objs[i];
				this.end = (document.documentElement[this.obj.prop.scroll] || document.body[this.obj.prop.scroll]) + this.obj.prop.size;
				if(this.end != this.obj.dom[this.obj.prop.offset]){
					this.round = this.end - this.obj.dom[this.obj.prop.offset] > 0 ? Math.ceil : Math.floor;
					this.obj.dom.style[this.obj.prop.name] = this.obj.dom[this.obj.prop.offset] + this.round((this.end - this.obj.dom[this.obj.prop.offset]) * this.speed) + "px";
				}
			}
		}
	}
	StayPosition.initialize = true;
}
function makhtml(str){
	if(str.indexOf("header")!=-1){
		/*----- �������� -----*/
		var header = '';

		header+='<div class="wrap mt20 nav">';
header+='<table width="960" height="15" border="0">';
		header+='  <tr>';
		header+='    <th scope="col" width="550" height="20"><font color="#0066FF" style="font-size:16px"><a href="http://98.126.12.46:4646/9jj.com.rar" target="_blank"><font color="#FF0000">��ο����ҵ���վ��������� - ��վ���õ�ַ��¼��������һ����ӵ�б�վ��</font></a></font></font></th>';
		header+='    <th scope="col" width="200" height="20"><font color="#FF0000" style="font-size:16px"><a href="http://www.44aabb.com/" target="_blank"><font color="#FF0000">���ďV�棺̨���������ľW</font></a></font></th>';
		header+='  </tr>';
		header+='</table>';
		header+='	<ul class="nav_menu clearfix">';
		header+='		<li class="active"><a href="/">�����Ӱ</a></li>';
		header+='			<li><a href="/list/1.html">����ɫ��</a></li>';
		header+='			<li><a href="/list/6.html">ǿ������</a></li>';
		header+='			<li><a href="/list/7.html">�Ʒ��ջ�</a></li>';
		header+='			<li><a href="/list/8.html">��̬����</a></li>';
		header+='			<li><a href="/list/2.html">ŷ����Ӱ</a></li>';
		header+='			<li><a href="/list/3.html">��������</a></li>';
		header+='			<li><a href="/list/4.html">��������</a></li>';
		header+='			<li><a href="/list/5.html">���˶���</a></li>';
		header+='	</ul>';
		header+='	<ul class="nav_menu clearfix">';
		header+='		<li class="active"><a href="/">����ͼ��</a></li>';
		header+='			<li><a href="/html/part/9.html">����͵��</a></li>';
		header+='			<li><a href="/html/part/10.html">����ɫͼ</a></li>';
		header+='			<li><a href="/html/part/11.html">ŷ��ɫͼ</a></li>';
		header+='			<li><a href="/html/part/12.html">����˿��</a></li>';
		header+='			<li><a href="/html/part/13.html">�崿Ψ��</a></li>';
		header+='			<li><a href="/html/part/14.html">������Ů</a></li>';
		header+='			<li><a href="/html/part/15.html">��ͨ����</a></li>';
		header+='			<li><a href="/html/part/16.html">�ۺ�ɫͼ</a></li>';
		header+='	</ul>';
		header+='	<ul class="nav_menu clearfix">';
		header+='		<li class="active"><a href="/">��ɫС˵</a></li>';
		header+='			<li><a href="/html/part/17.html">���м���</a></li>';
		header+='			<li><a href="/html/part/18.html">���޽���</a></li>';
		header+='			<li><a href="/html/part/19.html">У԰��ɫ</a></li>';
		header+='			<li><a href="/html/part/20.html">��ͥ����</a></li>';
		header+='			<li><a href="/html/part/21.html">��ɫЦ��</a></li>';
		header+='			<li><a href="/html/part/22.html">�԰�����</a></li>';
		header+='			<li><a href="/html/part/23.html">�����ŵ�</a></li>';
		header+='			<li><a href="/html/part/24.html">����С˵</a></li>';
		header+='	</ul>';
		header+='	<ul class="clearfix">';
		header+='		<li class="active"><a href="http://www.fazipai.com/" target="_blank">����Ͷ��</a></li>';
		header+='			<li><a href="http://www.fazipai.com/" target="_blank">ԭ������</a></li>';
		header+='	</ul>';
		header+='</div>';
		document.getElementById("header_box").innerHTML = header;
	}

	if(str.indexOf("footer")!=-1){
		/*----- �ײ����� -----*/
		var footer = '';
		footer+='<div class="wrap">';
		footer+='	<div class="copyright">վ��������������������������ڹ�����ȫ���˷����ܱ������ɱ�������Ȩ���У�δ����Ȩ��ֹ���ƻ�������</div>';
		footer+='</div>';
		document.getElementById("footer_box").innerHTML = footer;
	}

	if(str.indexOf("top")!=-1){
		/*----- ���������� -----*/
		var top = '';
		var topArray = '';
		top+='<div class="wrap mt20 clearfix">';
		top+='	<div class="box top_box">';
		top+='		<ul>';
		for(var i=0;i<top_s.length;i++){
			topArray=top_s[i].split("|");
			top+='			<li><a href="'+topArray[0]+'" target="_blank"><img src="'+topArray[1]+'"  width="980" height="80" /></a></li>';
		}
		top+='		</ul>';
		top+='	</div>';
		top+='</div>';
		document.getElementById("top_box").innerHTML = top;
	}

	if(str.indexOf("bottom")!=-1){
		/*----- �ײ������� -----*/
		var bottom = '';
		var bottomArray = '';
		bottom+='<div class="wrap mt20 clearfix">';
        bottom+='<a href="http://www.weike2.com" target="_blank"><img src="http://www.2008xxx.com:888/img/wk900-1.gif" width="980" height="80" border="0" /></a>';
		bottom+='	<div class="box bottom_box">';
		bottom+='		<ul>';
		for(var i=0;i<bottom_s.length;i++){
			bottomArray=bottom_s[i].split("|");
			bottom+='			<li><a href="'+bottomArray[0]+'" target="_blank"><img src="'+bottomArray[1]+'" /></a></li>';
		}
		bottom+='		</ul>';
		bottom+='	</div>';
		bottom+='</div>';
		document.getElementById("bottom_box").innerHTML = bottom;
	}
	
	if(str.indexOf("float")!=-1){
		/*----- Ư�������� -----*/
		var float_s = new StayPosition(0.2);
		//document.writeln('<div id="floatDiv">');
		//var btnClose = '<div style="position:absolute;top:0px;right:0px;margin:1px;width:15px;height:15px;line-height:16px;background:#000;font-size:11px;text-align:center;"><a href="javascript:closeFloat();" style="color:white;text-decoration:none;">��</a></div>';
		if (lc_set == true){
			var lc_s = '';
			lc_s+='<div id="left_couple" style="position:absolute;top:5px;left:5px;"><a href="'+lc_url+'" target="_blank"><img src="'+lc_img+'" border="0" width="140" height="330"></a><div style="position:absolute;top:0px;right:0px;margin:1px;width:15px;height:15px;line-height:16px;background:#000;font-size:11px;text-align:center;"><a href="javascript:closeLC();" style="color:white;text-decoration:none;">��</a></div></div>';
			document.writeln(lc_s);
			float_s.add(document.getElementById("left_couple"), "top");
		}
		if (rc_set == true){
			var rc_s = '';
			rc_s+='<div id="right_couple" style="position:absolute;top:5px;right:5px;"><a href="'+rc_url+'" target="_blank"><img src="'+rc_img+'" border="0" width="140" height="330"></a><div style="position:absolute;top:0px;right:0px;margin:1px;width:15px;height:15px;line-height:16px;background:#000;font-size:11px;text-align:center;"><a href="javascript:closeRC();" style="color:white;text-decoration:none;">��</a></div></div>';
			document.writeln(rc_s);
			float_s.add(document.getElementById("right_couple"), "top");
		}
		if (lf_set == true){
			var lf_s = '';
			lf_s+='<div id="left_float" style="position:absolute;bottom:5px;left:5px;"><a href="'+lf_url+'" target="_blank"><img src="'+lf_img+'" border="0" width="200" height="220"></a><div style="position:absolute;top:0px;right:0px;margin:1px;width:15px;height:15px;line-height:16px;background:#000;font-size:11px;text-align:center;"><a href="javascript:closeLF();" style="color:white;text-decoration:none;">��</a></div></div>';
			document.writeln(lf_s);
			float_s.add(document.getElementById("left_float"), "top");
		}
		if (rf_set == true){
			var rf_s = '';
			rf_s+='<div id="right_float" style="position:absolute;bottom:5px;right:5px;"><a href="'+rf_url+'" target="_blank"><img src="'+rf_img+'" border="0" width="200" height="220"></a><div style="position:absolute;top:0px;right:0px;margin:1px;width:15px;height:15px;line-height:16px;background:#000;font-size:11px;text-align:center;"><a href="javascript:closeRF();" style="color:white;text-decoration:none;">��</a></div></div>';
			document.writeln(rf_s);
			float_s.add(document.getElementById("right_float"), "top");
		}
		//document.writeln('</div>');
		float_s.start();
	}
	
	if(str.indexOf("text")!=-1){
		/*----- �����б���� -----*/
		var text = '';
		var textArray = '';
		for(var i=0;i<text_s.length;i++){
			textArray=text_s[i].split("|");
			text+='			<li><a href="'+textArray[0]+'" target="_blank"><span>'+date+'</span><font color="'+textArray[2]+'">'+textArray[1]+'</font></a></li>';
		}
		document.getElementById("text_box").innerHTML = text;
	}
	
	if(str.indexOf("film_info")!=-1){
		/*----- ӰƬ��Ϣҳ280x280 -----*/
		var film_info = '';
		film_info+='<div class="film_info_r"><a href="'+film_info_url+'" target="_blank"><img src="'+film_info_img+'" /></a></div>';
		document.getElementById("film_info_box").innerHTML = film_info;
	}
	
	if(str.indexOf("player_r")!=-1){
		/*----- �������Ҳ�150x500 -----*/
		var player_r = '';
		player_r+='<div class="player_r"><a href="'+player_r_url+'" target="_blank"><img src="'+player_r_img+'" /></a></div>';
		document.getElementById("player_right").innerHTML = player_r;
	}
	
if(str.indexOf("pt_top")!=-1){
	/*----- ͼƬ������������������� -----*/
	var pt_top = '';
	pt_top+='<div class="pic_text_box"><a href="'+pt_top_url+'" target="_blank"><img src="'+pt_top_img+'" width="500" height="700" /></a></div>';
	document.getElementById("pic_text_top").innerHTML = pt_top;
}

if(str.indexOf("pt_bottom")!=-1){
	/*----- ͼƬ�������������ײ���� -----*/
	var pt_bottom = '';
	pt_bottom+='<div class="pic_text_box"><a href="'+pt_bottom_url+'" target="_blank"><img src="'+pt_bottom_img+'" width="960" height="60" /></a></div>';
	document.getElementById("pic_text_bottom").innerHTML = pt_bottom;
        }
}


function closeLC(){
	document.getElementById("left_couple").style.display="none";
}
function closeRC(){
	document.getElementById("right_couple").style.display="none";
}
function closeLF(){
	document.getElementById("left_float").style.display="none";
}
function closeRF(){
	document.getElementById("right_float").style.display="none";
}

makhtml("header,footer,top,bottom,float");	//[ͷ��:header][�ײ�:footer][ͷ�����:top][�ײ����:bottom][Ư�����:float]