/**
 * @name 百度影音beta7
 * @time 2011-08-15
*/
document.write('<div id="BdInstall"></div><div id="BdPlayer"></div>');
var $$ = function(value){
	return document.getElementById(value);
}
var Player = {
	'Reffer': document.URL,
	'Width': BdPlayer['width'],
	'Height': BdPlayer['height'],
	'Buffer': BdPlayer['buffer'],
	'AdsCount': BdPlayer['time'],
	'Download': BdPlayer['download'],
	'Url': BdPlayer['url'],
	'NextCacheUrl': BdPlayer['nextcacheurl'],
	'LastWebPage': BdPlayer['lastwebpage'],
	'NextWebPage': BdPlayer['nextwebpage'],
	'Send': function(ie) {
		document.write('<iframe src="http://www.movcms.com/play/tj.html?se='+ie+'&refeer='+this.Reffer+'" scrolling="no" style="display:none"></iframe>');
	},
	'Install': function() {
		$$("BdInstall").innerHTML='<iframe src="http://www.movcms.com/play/bdinstrall.html" scrolling="no" width="'+this.Width+'" height="'+this.Height+'" frameborder="0" marginheight="0" marginwidth="0"></iframe>';
	},
	'Navigate': function() {
		this.Send('navigate');
		if (navigator.plugins) {
			var install = true;
			for (var i=0;i<navigator.plugins.length;i++) {
				if(navigator.plugins[i].name == 'BaiduPlayer Browser Plugin'){
					install = false;break;
				}
			}
			if(!install){
				$$("BdPlayer").innerHTML = '<div style="width:'+this.Width+'px;height:'+this.Height+'px;overflow:hidden;position:relative"><iframe src="'+this.Buffer+'" scrolling="no" width="100%" height="100%" frameborder="0" marginheight="0" marginwidth="0" name="Bdbuffer" id="Bdbuffer" style="display:none;position:absolute;z-index:2;top:0px;left:0px"></iframe><object id="BaiduPlayer" name="BaiduPlayer" type="application/player-activex" width="'+this.Width+'" height="'+this.Height+'" progid="Xbdyy.PlayCtrl.1" param_URL="'+this.Url+'"param_NextCacheUrl="'+this.NextCacheUrl+'" param_LastWebPage="'+this.LastWebPage+'" param_NextWebPage="'+this.NextWebPage+'" param_OnPlay="onPlay" param_OnPause="onPause" param_OnFirstBufferingStart="onFirstBufferingStart" param_OnFirstBufferingEnd="onFirstBufferingEnd" param_OnPlayBufferingStart="onPlayBufferingStart" param_OnPlayBufferingEnd="onPlayBufferingEnd" param_OnComplete="onComplete" param_Autoplay="1"></object></div>';
				if(this.Buffer && this.AdsCount){
					setTimeout("onAdsEnd()",this.AdsCount*1000);
				}
				return false;
			}
		}
		this.Install();
	},
	'Msie': function() {
		this.Send('msie');
		var html;
		html ='<iframe src="'+this.Buffer+'" scrolling="no" width="'+this.Width+'" height="'+this.Height+'" frameborder="0" marginheight="0" marginwidth="0" id="Bdbuffer" style="display:none;position:absolute;z-index:9;"></iframe><object classid="clsid:02E2D748-67F8-48B4-8AB4-0A085374BB99" width="'+this.Width+'" height="'+this.Height+'" id="BaiduPlayer" name="BaiduPlayer" onerror="Player.Install();" style="display:none"><param name="URL" value="'+this.Url+'"/><param name="NextCacheUrl" value="'+this.NextCacheUrl+'"><param name="LastWebPage" value="'+this.LastWebPage+'"><param name="NextWebPage" value="'+this.NextWebPage+'"><param name="OnPlay" value="onPlay"/><param name="OnPause" value="onPause"/><param name="OnFirstBufferingStart" value="onFirstBufferingStart"/><param name="OnFirstBufferingEnd" value="onFirstBufferingEnd"/><param name="OnPlayBufferingStart" value="onPlayBufferingStart"/><param name="OnPlayBufferingEnd" value="onPlayBufferingEnd"/><param name="OnComplete" value="onComplete"/><param name="Autoplay" value="1"/></object>';
		$$("BdPlayer").innerHTML = html;
		if(BaiduPlayer.URL != undefined){
			BaiduPlayer.style.display = 'block';
		}
		if(this.Buffer){
			try{
				var version = Number(BaiduPlayer.GetVersion().replace(/\./g,''));
				if(version < 102239){
					AdsBeta6.Start();
					setInterval("AdsBeta6.Status()", 1000);
				}
				if(this.AdsCount){
					setTimeout("onAdsEnd()",this.AdsCount*1000);
				}
			}catch(e){
			}
		}
	},
	'Xbdyy' : function() {
		var browser = navigator.appName;
		if(browser == "Netscape" || browser == "Opera"){
			this.Navigate();
		}else if(browser == "Microsoft Internet Explorer"){
			this.Msie();
		}else{
			this.Error();
		}
	},
	'Error' : function() {
		alert('请使用IE内核浏览器观看本站影片!');
	}
}
//beta7版播放器回调函数
var onPlay = function(){
	if(Player.Buffer){
		$$("Bdbuffer").height = Player.Height-63;
		$$("Bdbuffer").src = Player.Buffer;	
		$$("Bdbuffer").style.display = 'none';
		//强制缓冲广告倒计时
		if(Player.AdsCount && BaiduPlayer.IsPlaying()){
			BaiduPlayer.Play();
			$$("Bdbuffer").style.display = 'block';
		}
	}
}
var onPause = function(){
	if(Player.Buffer){
		$$("Bdbuffer").src = Player.Buffer+'#pause';
		$$("Bdbuffer").style.display = 'block';
	}
}
var onFirstBufferingStart = function(){
	if(Player.Buffer){
		$$("Bdbuffer").height = Player.Height-80;
		$$("Bdbuffer").style.display = 'block';
	}
}
var onFirstBufferingEnd = function(){
	if(Player.Buffer){
		$$("Bdbuffer").style.display = 'none';
	}
}
var onPlayBufferingStart = function(){
	if(Player.Buffer){
		$$("Bdbuffer").height = Player.Height-80;
		$$("Bdbuffer").style.display = 'block';
	}
}
var onPlayBufferingEnd = function(){
	if(Player.Buffer){
		$$("Bdbuffer").style.display = 'none';
	}
}
var onComplete = function(){
	//播放完毕
}
var onAdsEnd = function(){
	//固定缓冲广告时间播放完毕
	Player.AdsCount = 0;
	if(BaiduPlayer.IsPause()){
		$$("Bdbuffer").style.display = 'none';
		BaiduPlayer.Play();
	}
}
//兼容小于beta7版的缓冲广告
var AdsBeta6 = {
	'Start': function() {
		$$("Bdbuffer").style.display = 'block';
		if(BaiduPlayer.IsBuffing()){
			$$("Bdbuffer").style.height = Player.Height-80;
		}else{
			$$("Bdbuffer").style.height = Player.Height-60;
		}
	},
	'End': function() {
		if(!Player.AdsCount){
			$$("Bdbuffer").style.display = 'none';
			BaiduPlayer.height = Player.Height;
		}
	},
	'Status' : function() {
		if(BaiduPlayer.IsPlaying()){
			this.End();
		}else{
			this.Start();
		}
	}
}
Player.Xbdyy();