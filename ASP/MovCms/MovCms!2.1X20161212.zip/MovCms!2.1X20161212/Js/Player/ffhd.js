
function isIE() {
	if (!!window.ActiveXObject || "ActiveXObject" in window)  
		return true;  
	else  
		return false;  
}  
function $ShowSetup() {
	return '<iframe src="http://user.movcms.com:99/play/ffhd_instrall.html" width="100%" height="'+ffhd_h+'" marginWidth="0" frameSpacing="0" marginHeight="0" frameBorder="0" scrolling="no" vspale="0" noResize></iframe>';
}
function WriteShowSetup(){
	document.getElementById('FFHDPlayer').style.display='none';
	document.write($ShowSetup());
}
function $PlayerNt(){
	if (navigator.plugins) {
		var install = true;
		for (var i=0;i<navigator.plugins.length;i++) {
			if(navigator.plugins[i].name == 'FFPlayer Plug-In'){
				install = false;break;
			}
		}
		if(!install){
			player = '<object id="FFHDPlayer" name="FFHDPlayer" type="application/npFFPlayer" width="100%" height="'+ffhd_h+'" progid="XLIB.FFPlayer.1" url="'+ffhd_url+'" CurWebPage="'+ffhd_weburl+'"></object>';
			return player;
		}
	}
	return $ShowSetup();
}
function $PlayerIe(){
	player = '<object classid="clsid:D154C77B-73C3-4096-ABC4-4AFAE87AB206" width="100%" height="'+ffhd_h+'" id="FFHDPlayer" name="FFHDPlayer" onerror="WriteShowSetup();"><param name="url" value="'+ffhd_url+'"/><param name="CurWebPage" value="'+ffhd_weburl+'"/></object>';
	return player;
}
function $Showhtml(){
	if(!isIE()){
		return $PlayerNt();
	}else{
		return $PlayerIe();
	}
}
document.write($Showhtml());

