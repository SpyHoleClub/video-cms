//�Զ����������������ַ
function url_add(n)
{
var a="document.all.url_all_"
var b=".value"
var str='';
var url_all=eval("document.all.url_all_"+''+n+''+".value");
var url_name=eval("document.all.url_name_"+''+n+''+".value");
var url_ji=eval("document.all.url_ji_"+''+n+''+".value");
if(!url_ji) url_ji=1;

for(i=1;i<=url_ji;i++)
{
var a=i //�±���
if(url_ji<10)
	{
	i='0'+i
	}  
else if(url_ji<100)
	{
		if(i<10)
		{
		i='0'+i
		}
	} 
else if(url_ji<1000)
	{
		if(i<10)
		{
		i='00'+i
		} 
		else if(i<100)
		{
		i='0'+i
		}
	}
//��ϲ��ŵ�ַ��ʼ
if(a==1)
	{
	str+=url_all.replace("{$}",i)+i+url_name;
	}
else	
	{	
	str+='\n'+url_all.replace("{$}",i)+i+url_name;
	}
//��ϲ��ŵ�ַ����	
}

eval("form_url.url_intro_"+n+".value=''+str+''"); 
}
//����������ת��ť
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  //eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  location.href=selObj.options[selObj.selectedIndex].value
  if (restore) selObj.selectedIndex=0;
}
//����������֤����
function CheckForm()
{
  if (document.form1.class_id.value==''){
    alert('��ѡ����࣡');
    document.form1.class_id.focus();
    return false;
  } 
  if (document.form1.data_name.value==''){
    alert('ӰƬ���Ʋ���Ϊ�գ�');
    document.form1.data_name.focus();
    return false;
  }
  if (document.form1.data_actor.value==''){
    alert('�������ݲ���Ϊ�գ�');
    document.form1.data_actor.focus();
    return false;
  } 
  //if (document.form1.data_playpath.value==''){
   // alert('�����ˣ���ѡ�񲥷�Դ����');
    //document.form1.data_actor.focus();
   // return false;
 //} 
}
//����������֤����
function CheckSkin()
{
  if (document.skin.htmlcontent.value==''){
    alert('����дģ������!');
    document.skin.htmlcontent.focus();
    return false;
  }
}
//���ӽ�Ʒ��֤����
function JaJapForm()
{
  if (document.form1.p_name.value==''){
    alert('���뽱Ʒ���ƣ�');
    document.form1.p_name.focus();
    return false;
  } 
  if (document.form1.p_how.value==''){
    alert('���뽱Ʒ������');
    document.form1.p_how.focus();
    return false;
  } 
   if (document.form1.p_jf.value==''){
    alert('����һ����֣�');
    document.form1.p_jf.focus();
    return false;
  } 
}

//��Ҫ����ɾ������2��ȷ��
function qvodcmsdel(url,str1,str2)
{
    question = confirm(str1)
    if (question != "0")
	{
	question = confirm(str2)
		if (question != "0")
		{
		//window.open("http://www.qvodcms.com")
		location.href=url;
		}
    }
}

//����������֤����
function NewsForm()
{
  if (document.form1.Title.value==''){
    alert('����д���ű��⣡');
    document.form1.Title.focus();
    return false;
  } 
  if (document.form1.class_id.value==0){
    alert('��ѡ�����ŷ��࣡');
    document.form1.class_id.focus();
    return false;
  } 
}
function getElementsByName(tag,name){
    var rtArr=new Array();
    var el=document.getElementsByTagName(tag);
    for(var i=0;i<el.length;i++){
        if(el[i].name==name)
              rtArr.push(el[i]);
    }
    return rtArr;
}
//ȫѡ��ѡ
function CheckAll(name)
{
    var checkboxArray;checkboxArray=document.getElementsByName(name)
	for (var i=0;i<checkboxArray.length;i++){
		if (checkboxArray[i].checked == false){
			checkboxArray[i].checked = true;
		}else if (checkboxArray[i].checked == true){
			checkboxArray[i].checked = false;
		}
	}
}

//ȫѡ��ѡ
function checkOthers(tagname,name)
{
	var checkboxArray;checkboxArray=document.getElementsByName(name)
	for (var i=0;i<checkboxArray.length;i++){
		if (checkboxArray[i].checked == false){
			checkboxArray[i].checked = true;
		}else if (checkboxArray[i].checked == true){
			checkboxArray[i].checked = false;
		}
	}
}
//���ɵ�����ҳ
function ops(str1,str2,str3){
dWin=showModalDialog(str1,window,'dialogHeight:'+str2+'px;dialogWidth:'+str3+'px;scroll:no;resizable:no;status:no;help:no');
}

//ajax response
function rea(rurl) {
    var obj = $.ajax({
        url: rurl,
        async: false
    });
    var msg = obj.responseText;
	return msg;
};
//�������
function set_jc(type,id,value){
    var url="QvodCms_Ajax.asp?action="+type+"&value="+value,msg = rea(url);
	$("#"+id).val(msg);
};

//�����Ƽ����
function setajax(type,id,value){
    var url="QvodCms_Ajax.asp?action="+type+"&dataid="+id+"&value="+value,msg = rea(url);
	$("#"+type+id).html(msg);
};
//��������ר��
function setajaxct(typeid,dataid){
	if (typeid=="1") {
		var state = document.getElementById("datacontinu").value;
		if(state == 'undefined' || state == ''){
			alert('��������Ϊ��');
			return false;
		}
		var url="QvodCms_Ajax.asp?action=ct&dataid="+dataid+"&value="+state,msg = rea(url);$("#ct"+dataid).html(msg);
	}
	if (typeid=="2"){
		var state = document.getElementById("specialid").value;
		var url="QvodCms_Ajax.asp?action=sp&dataid="+dataid+"&value="+state,msg = rea(url);$("#sp"+dataid).html(msg);
	}
	if (typeid=="3"){
		var state = document.getElementById("weekid").value;
		var url="QvodCms_Ajax.asp?action=wk&dataid="+dataid+"&value="+state,msg = rea(url);$("#wk"+dataid).html(msg);
	}
	closeLayer();
}
function oncompletecontent(obj){
	if(obj.responseText){
		alert(obj.responseText);
	}
}
//��ʾ����ר��
function setday(datatype,dataid,specialid){
	var iWidth = document.documentElement.scrollWidth-20; 
	var iHeight = document.documentElement.scrollHeight; 
	var bgObj = document.createElement("div");
	bgObj.style.cssText = "position:absolute;left:0px;top:0px;width:"+iWidth+"px;height:"+Math.max(document.body.clientHeight, iHeight)+"px;filter:Alpha(Opacity=50);opacity:0.3;background-color:#ffffff;z-index:101;";
	bgObj.id="bgObj";
	document.body.appendChild(bgObj); 
	var divObj = document.createElement("div");
	
	if (datatype=="playurl"){
	divObj.style.cssText ="position: absolute;z-index:102;width:90px;border:1px solid #ffbe8c;background: #fff1e7;";
	}
	else{
		divObj.style.cssText ="position: absolute;z-index:102;width:237px;height:22px;margin-left:-10px;border:1px solid #ffbe8c;background: #fff1e7;padding:4px 0px 3px 4px;";
		}
	
	divObj.id="divObj";
	document.body.appendChild(divObj);
	var obj = document.getElementById(datatype+dataid);
	var th = obj; 
	var ttop = obj.offsetTop;
    var tleft = obj.offsetLeft; 
    while (obj = obj.offsetParent){ttop+=obj.offsetTop; tleft+=obj.offsetLeft;}
    divObj.style.top = (ttop-1)+"px";
    divObj.style.left = (tleft-1)+"px";
	if (datatype=="ct"){
		divObj.innerHTML='�Զ��壺<input type="text" size="10" id=datacontinu name="datacontinu"> <input type="button" value="ȷ��" onclick="setajaxct(1,'+dataid+');"/> <input type="button" value="ȡ��" onclick="closeLayer()"/>';
	}
	if (datatype=="playurl"){
		divObj.innerHTML="���ڼ���";
		var url="QvodCms_Ajax.asp?action=ly&dataid="+dataid+"&value=",msg = rea(url);
		divObj.innerHTML=msg
	}
	if (datatype=="sp"){
		divObj.innerHTML="���ڼ���";
		var url="QvodCms_Ajax.asp?action=zt&dataid="+dataid+"&value="+specialid,msg = rea(url);
		divObj.innerHTML=msg
	}
	if (datatype=="wk"){
		divObj.innerHTML="���ڼ���";
		var url="QvodCms_Ajax.asp?action=week&dataid="+dataid+"&value="+specialid,msg = rea(url);
		divObj.innerHTML=msg
	}
}
//�ر�����ר��
function closeLayer() {
	document.body.removeChild(bgObj);
	document.body.removeChild(divObj);
}
//data_add.asp����
function showcheckbox(cname,dname){
	if(document.getElementById(cname).checked==true){
	showThumbnail_RateOrSize(1,dname);
	}else{
	showThumbnail_RateOrSize(0,dname);
	}
}
function showThumbnail_RateOrSize(param,pname){
	if(param==1){
		document.getElementById(pname).style.display="block";
	}else{
		document.getElementById(pname).style.display="none";
	}
}
//��Ƶ��������
function ShowWinCaiji(i){
	$('caijibox').style.display='block';
	$("caijiid").value=i;
	selfLabelWindefault('caijibox');
}
function gathering(){
	var url=$("caijiurl").value;
	$("caijiintro").value = '���ݲɼ���...���Ե�';
	var ajax = new AJAXRequest();
	ajax.get("CaiJi/Cai_FlashInc.asp?url="+url+"",function(ajaxobj){
		      if(ajaxobj.responseText == "err"){$("caijiintro").value = "��������";}else{$("caijiintro").value = ajaxobj.responseText;}
			});	
}
function insertResult(){
	var id=$("caijiid").value;
	$("url_intro_"+id).value = $("caijiintro").value;
	$("caijiid").value='';
	$("caijiurl").value='';
	$("caijiintro").value='';
	caijihide('caijibox');
}
function addResult(){
	var id=$("caijiid").value;
	$("url_intro_"+id).value += "\n"+$("caijiintro").value;
}
function trimOuterStr(str,outerstr){
	var len1
	len1=outerstr.length;
	if(str.substr(0,len1)==outerstr){str=str.substr(len1)}
	if(str.substr(str.length-len1)==outerstr){str=str.substr(0,str.length-len1)}
	return str
}
function reverseOrder(){
	if($('caijiintro').value==""){alert("û�е�ַ����");return;}
	if(navigator.userAgent.indexOf("Firefox")>0){var listArray=$('caijiintro').value.split("\n");}else{var listArray=$('caijiintro').value.split("\r\n");}
	var newStr="";
	for(var i=listArray.length-1;i>=0;i--){
			newStr+=listArray[i]+"\r\n";
	}
	$('caijiintro').value=trimOuterStr(newStr,"\r\n");
}
function replaceStr(){
	var contentObj=$('caijiintro'),str="gi";
	if(contentObj.value==""){alert("û�е�ַ����");return;}
	var replace1=$("replace1").value,replace2=$("replace2").value;
	var content=contentObj.value;
	var reg=new RegExp(replace1,str);
	contentObj.value=content.replace(reg,replace2);	
}
//
function selfLabelWindefault(divid){
	$(divid).style.left=(document.documentElement.clientWidth-568)/2+"px"
	//$(divid).style.top=(getScroll()+60)+"px"
	$(divid).style.top="100px"
}
function getScroll(){
    var t;if(document.documentElement&&document.documentElement.scrollTop){t=document.documentElement.scrollTop;}else if(document.body){t=document.body.scrollTop;}return(t);
}
function caijihide(id){//�رղ�
    $(id).style.display='none';
}
//
function hL(E,tagname){
  while (E.tagName!=tagname) {E=E.parentElement;}
  E.className='tdbg2';
}
function dL(E,tagname){
  while (E.tagName!=tagname) {E=E.parentElement;}
  E.className='tdbg';
}

function RemoveData(str,pid) {
if (confirm(str)==true){
	$('#playfb'+pid).remove();
return true;
}else{
return false;
}
} 

function X(id) {
	return document.getElementById(id)
}


function moveTableUp(o){
	var o=X(o)
	//alert (o)
	if(!!o.previousSibling){
		o.parentNode.insertBefore(o,o.previousSibling);
	}
}
function moveTableDown(o){
	var o=X(o)
	if(!!o.nextSibling){
		o.parentNode.insertBefore(o.nextSibling,o);
	}
} 
   

function data_tags(id){
	var tag=document.getElementById("data_tag").value;
    document.getElementById("data_tag").value=tag+','+id;
	}
function css_close(id)
{
  $("."+id).fadeOut(500);
  return false;
}
function css_open(id)
{
  $("."+id).fadeIn(500);
  return false;
}

function ac_open(id)
{
  $("#"+id).slideToggle("slow");
}