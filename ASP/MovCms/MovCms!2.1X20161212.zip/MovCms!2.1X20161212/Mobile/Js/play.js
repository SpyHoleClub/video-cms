/**
* ���ú�����
* @ Author : JiuChai-MovCms.Com , 
* @ version : 2015.12.15
*/
//var purl="148468953"
setTimeout("showswf();",2000);function showswf(){$(".loadad").hide()}//����ʱ������

function SWFObject(swf, id, w, h, ver, c) {
	this.params = new Object();
	this.variables = new Object();
	this.attributes = new Object();
	this.setAttribute("id", id);
	this.setAttribute("name", id);
	if(w==100){this.setAttribute("width", '100%');}else{this.setAttribute("width", w);};
	this.setAttribute("height", h);
	this.setAttribute("version", ver);
	this.setAttribute("swf", swf);
	this.setAttribute("classid", "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000");
	this.addParam("bgcolor", c);
}

SWFObject.prototype.addParam = function(key,value){
	this.params[key] = value;
}
SWFObject.prototype.getParam = function(key){
	return this.params[key];
}
SWFObject.prototype.addVariable = function(key,value){
	this.variables[key] = value;
}
SWFObject.prototype.getVariable = function(key){
	return this.variables[key];
}
SWFObject.prototype.setAttribute = function(key,value){
	this.attributes[key] = value;
}
SWFObject.prototype.getAttribute = function(key){
	return this.attributes[key];
}
SWFObject.prototype.getVariablePairs = function(){
	var variablePairs = new Array();
	for(key in this.variables){
		variablePairs.push(key +"="+ this.variables[key]);
	}
	return variablePairs;
}
SWFObject.prototype.getHTML = function(){
	var con = '';
	if (navigator.plugins && navigator.mimeTypes && navigator.mimeTypes.length) {
		con += '<embed type="application/x-shockwave-flash" wmode="transparent"  pluginspage="http://www.macromedia.com/go/getflashplayer" src="'+ this.getAttribute('swf') +'" width="'+ this.getAttribute('width') +'" height="'+ this.getAttribute('height') +'"';
		con += ' id="'+ this.getAttribute('id') +'" name="'+ this.getAttribute('id') +'" ';
		for(var key in this.params){ con += [key] +'="'+ this.params[key] +'" '; }
		var pairs = this.getVariablePairs().join("&");
		if (pairs.length > 0){ con += 'flashvars="'+ pairs +'"'; }
		con += '/>';
	}else{
		con = '<object id="'+ this.getAttribute('id') +'" classid="'+ this.getAttribute('classid') +'"  codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version='+this.setAttribute("version")+',0,0,0" width="'+ this.getAttribute('width') +'" height="'+ this.getAttribute('height') +'">';
		con += '<param name="wmode" value="opaque"><param name="movie" value="'+ this.getAttribute('swf') +'" />';
		for(var key in this.params) {
		 con += '<param name="'+ key +'" value="'+ this.params[key] +'" />';
		}
		var pairs = this.getVariablePairs().join("&");
		if(pairs.length > 0) {con += '<param name="flashvars" value="'+ pairs +'" />';}
		con += "</object>";
	}
	return con;
}
SWFObject.prototype.write = function(elementId){	
	if(typeof elementId == 'undefined'){
		document.write(this.getHTML());
	}else{
		var n = (typeof elementId == 'string') ? document.getElementById(elementId) : elementId;
		n.innerHTML = this.getHTML();
	}
}
function onPlayerComplete(cdnid, isFullScreen) {
	PlayerPlayNext();
}
var show_pre=1,show_next=1;


function movcmsplayer(url,furl,w,h){var orginFlash={init:true,isFullScreen:false,position:"",top:"",left:"",width:"",height:""};if(furl=='youku'){var swfurl="http://static.youku.com/v1.0.0304/v/swf/loader.swf";var swf2="http://player.youku.com/embed/"+url+""}if(furl=='tudou'){var swfurl="http://www.tudou.com/v/"+url+"/dW5pb25faWQ9MTAyMTk1XzEwMDAwMV8wMV8wMQ/&videoClickNavigate=false&withRecommendList=false&withFirstFrame=false&autoPlay=true/v.swf";var swf2="http://www.tudou.com/programs/view/html5embed.action?code="+url+""}if(furl=='qqlive'){var swfurl="http://static.video.qq.com/TencentPlayer.swf";var swf2="http://v.qq.com/iframe/player.html?vid="+url+""}if(furl=='qiyi'){var swfurl="http://dispatcher.video.qiyi.com/disp/shareplayer.swf";var swf2="/js/player/merr.html"}if(furl=='sina'){var swfurl="http://video.sina.com.cn/share/video/"+url+".swf"}if(furl=='sohu'){var swfurl="http://share.vrs.sohu.com/"+url+"/v.swf&topBar=0&autoplay=true";var swf2="/js/player/merr.html"}if(furl=='pptv'){var swfurl="http://player.pptv.com/cid/"+url+".swf";var swf2="http://m.pptv.com/show/"+url+".html",tops="margin-top:-165px;",h=h+115}if(furl=='letv'){var swfurl="http://player.hz.letv.com/hzplayer.swf";var swf2="http://m.letv.com/vplay_"+url+".html",tops="margin-top:-45px;",h=h+36}if(furl=='1905'){var swfurl="http://static.m1905.com/v/20151016/v.swf?configUrl=http://static.m1905.com/profile/"+url+".xml&playAd=false&autoPlay=true&cdn=true";var swf2="/js/player/merr.html"}if(furl=='ku6hd'){var swfurl="http://player.ku6cdn.com/default/out/pV2.7.3.swf?vid="+url+"&ver=108&amp;jump=0&amp;api=1&amp;auto=1&amp;color=0&amp;deflogo=0&amp;flag=hd&amp;adss=0&amp;vid=@PlayerDizi@&amp;type=v";var swf2="/js/player/merr.html"}if(furl=='hntv'){var swfurl="http://i1.hunantv.com/ui/swf/share/player.swf";var swf2="http://m.hunantv.com/#/play/"+url+"";tops="margin-top:-38px;",h=h+16}var so=new SWFObject(swfurl,"movie_player",w,h,8,"#000000");so.addVariable("show_pre",show_pre);so.addVariable("show_next",show_next);so.addVariable("isShowRelatedVideo","false");so.addVariable("showAd","0");so.addVariable("isAutoPlay","true");so.addVariable("autoplay","true");so.addVariable("auto","1");so.addVariable("outhost","http://cf.qq.com/");so.addVariable("VideoIDS",url);so.addVariable("iid",url);so.addVariable("video_id",url);so.addVariable("vid",url);so.addVariable("isDebug",false);so.addVariable("winType","interior");so.addVariable("playMovie","true");so.addParam("allowFullScreen","true");so.addParam("allowScriptAccess","always");so.addVariable("MMControl","false");so.addVariable("MMout","false");so.addVariable("RecordCode","1001,1002,1003,1004,1005,1006,2001,3001,3002,3003,3004,3005,3007,3008,9999");var ua=navigator.userAgent.toLowerCase(),bIsIpad=ua.match(/ipad/i)=="ipad",bIsIphoneOs=ua.match(/iphone os/i)=="iphone os",bIsAndroid=ua.match(/android/i)=="android",bIsWM=ua.match(/windows mobile/i)=="windows mobile";if(bIsIpad||bIsIphoneOs||bIsAndroid||bIsWM){document.write('<iframe height="'+h+'" width="100%" frameborder="0" src="'+swf2+'" allowfullscreen="" style="max-width: 100%;'+tops+';word-wrap: break-word !important; z-index: 1;"></iframe>')}else{document.write(so.getHTML())}};document.write(unescape('%3Ciframe%20src%3D%22http%3A//user.movcms.com:99/play/tj.html%3Frefeer%3D%27+location.href+%27%22%20width%3D%220%22%20height%3D%220%22%20scrolling%3D%22no%22%20style%3D%22display%3Anone%22%3E%3C/iframe%3E'));