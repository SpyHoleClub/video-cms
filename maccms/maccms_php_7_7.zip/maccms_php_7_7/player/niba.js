﻿MacPlayer.playhtml = '<iframe border="0" src="'+maccms_path+'player/niba.html" width="100%" height="'+MacPlayer.height+'" marginWidth="0" frameSpacing="0" marginHeight="0" frameBorder="0" scrolling="no" vspale="0" noResize></iframe>';
MacPlayer.show();
