<?php
define("app_ftp",0);        //ftp开关
define("app_ftphost","img.maccms.com");        //ftp主机ip
define("app_ftpuser","img.maccms.com");        //ftp帐号
define("app_ftppass","123456");        //ftp密码
define("app_ftpdir","/wwwroot/");        //ftp目录
define("app_ftpport","21");        //ftp端口
define("app_ftpurl","http://img.maccms.com/");        //ftp远程附件访问地址
define("app_ftpdel",0);        //上传成功后是否删除本地文件
?>