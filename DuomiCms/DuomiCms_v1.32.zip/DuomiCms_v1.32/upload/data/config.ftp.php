<?php
$app_ftp = '0';
$app_ftphost = 'test.duomicms.net';
$app_ftpuser = 'duomicmstest';
$app_ftppass = 'duomicmstest';
$app_ftpport = '21';
$app_ftpdir = '/';
$app_ftpurl = 'http://test.duomicms.net';
$app_ftpdel = '0';
$app_updatepic = '0';
?>