<?php
require_once(dirname(__FILE__)."/config.php");
require(duomi_INC.'/image.func.php');
include(duomi_ADMIN.'/html/index_body.htm');
exit();
?>