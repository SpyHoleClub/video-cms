<?php 
/**
*  Geetest配置文件
* @author Tanxu
*/

//下面数据，请登陆  http://www.geetest.com/  获取

define("CAPTCHA_ID", "aaaaaaa");
define("PRIVATE_KEY", "bbbbbbbbbbbbb");

?>