<?php
define('Web_Name','Ctcms管理系统'); //站点名称  
define('Web_Url','free.ctcms.cn'); //站点域名  
define('Web_Path','/'); //站点路径  
define('Web_Off',0);  //网站开关  
define('Web_Onneir','网站升级维护中，给大家带来不便，请谅解...');  //网站关闭内容  
define('Web_Mode',2);  //网站运行模式  
define('Web_Icp','沪ICP备06000000号');  //网站ICP  
define('Web_Count','统计代码');  //统计代码  
define('Web_Title','Ctcms视频系统'); //SEO-标题  
define('Web_Keywords','Ctcms视频系统'); //SEO-Keywords  
define('Web_Description','Ctcms视频系统'); //SEO-description  
define('Web_Skin','default'); //网站默认模板  
define('Admin_QQ','157503886');  //站长QQ  
define('Admin_Mail','admin@ctcms.cn');  //站长EMAIL  
define('Admin_Code','admin');  //后台验证码  
define('Admin_Log_Day',30);  //后台登陆日志保存天数  
define('Admin_Log_Ip','');  //允许访问后台的IP列表  
define('Cache_Is',0);  //缓存开关  
define('Cache_Time',1800);  //缓存时间  
define('Base_Path','/packs/'); //附件路径，包含后台css、js、images  
define('Wap_Is',1);  //手机版开关
define('Wap_Url','');  //手机版地址
define('Wap_Skin','default');  //手机版模版
define('Uri_Mode',0);  //是否启用Url路由  
define('Uri_List','list/[cid]~[page].html');  //分类页路由规则  
define('Uri_Show','show/[id].html');  //内容页路由规则  
define('Uri_Play','play/[id]~[zu]~[ji].html');  //播放页路由规则  
define('Web_Diqu','大陆|香港|台湾|美国|日本|韩国|其他');  //地区  
define('Web_Yuyan','国语|粤语|台语|英语|日语|韩语|其他');  //语言  
define('Web_Year','2016|2015|2014|2013|2012|2011|2010|2009|2008|更早');  //年份  
define('Web_Type','1#传记|喜剧|剧情|枪战|恐怖|励志|歌舞|犯罪|偶像|悬疑|爱情|惊悚|纪录|青春|科幻|冒险|魔幻|丧尸|动作|幻想|战争|情色|血腥|西部|童话|暴力|古装|灾难|谍战|生活|讽刺|同性
2#古装|武侠|警匪|军事|神话|悬疑|科幻|历史|儿童|言情|农村|谍战|偶像|家庭|都市|时装
3#热血|格斗|恋爱|美少女|校园|搞笑|LOLI|神魔|机战|科幻|真人|青春|魔法|神话|冒险|运动|竞技|童话|亲子|教育|励志|剧情|社会|历史|战争
4#脱口秀|真人秀|选秀|美食|旅游|汽车|访谈|纪实|搞笑|时尚|晚会|理财|演唱会|益智|音乐|舞蹈|游戏|生活');  //类型  
define('Web_Pl','评论关闭');  //评论代码  
define('Gbook_Is',1);  //留言开关  
define('Gbook_Sh',1);  //留言需要审核  
define('Gbook_Str','妈的|去死|垃圾');  //留言过滤关键字