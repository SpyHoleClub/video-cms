<?php
//程序版本
define("Ct_Upurl","http://api.ctcms.cn/free/");
define("Ct_Version","1.0.3");
define("Ct_Code","utf8");